﻿using asp.net_final_assignment.Data;
using asp.net_final_assignment.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace asp.net_final_assignment.Controllers
{
    public class HomeController : Controller
    {
        private readonly VehicleDbContext vehicleDbContext;
        public HomeController(VehicleDbContext vehicleDbContext)
        {
            this.vehicleDbContext = vehicleDbContext;    
        }
        public bool AuthCheck()
        {
            return User.Identity.IsAuthenticated;
        }
        [HttpGet]
        [Route("/")]
        public async Task<IActionResult> Index()
        {
            if (!AuthCheck())
            {
                return RedirectToAction("Login", "Account");
            }
            var totalVehicles = await vehicleDbContext.Cars.CountAsync();
            var rentedVehicles = await vehicleDbContext.Cars.CountAsync(c => c.Status == "Rented");
            var availableVehicles = await vehicleDbContext.Cars.CountAsync(c => c.Status == "Available");
            var maintenanceVehicles = await vehicleDbContext.Cars.CountAsync(c => c.Status == "Maintenance");

            var totalCustomers = await vehicleDbContext.Customers.CountAsync();

            var currentMonth = DateTime.Now.Month;
            var currentYear = DateTime.Now.Year;
            var newCustomersThisMonth = await vehicleDbContext.Customers
                .Where(c => c.Reservations.Any())
                .Where(c => c.Reservations
                    .OrderBy(r => r.Start)
                    .FirstOrDefault().Start.Month == currentMonth &&
                            c.Reservations.OrderBy(r => r.Start)
                    .FirstOrDefault().Start.Year == currentYear)
                .CountAsync();

            // Upcoming Reservations
            var now = DateTime.Now;
            var upcomingReservations = await vehicleDbContext.Reservations
                .CountAsync(r => r.Start > now);

            // Compare total reservations this month vs last month
            var thisMonthStart = new DateTime(now.Year, now.Month, 1);
            var nextMonthStart = thisMonthStart.AddMonths(1);
            var lastMonthStart = thisMonthStart.AddMonths(-1);

            var totalThisMonth = await vehicleDbContext.Reservations
                .CountAsync(r => r.Start >= thisMonthStart && r.Start < nextMonthStart);
                                            
            var totalLastMonth = await vehicleDbContext.Reservations
                .CountAsync(r => r.Start >= lastMonthStart && r.Start < thisMonthStart);

            var diff = totalThisMonth - totalLastMonth;
            var diffText = (diff >= 0 ? "+" : "") + diff.ToString();

            var recentCustomers = vehicleDbContext.Customers
                .Include(c => c.Reservations)
                .ThenInclude(r => r.Car)
                .Where(c => c.Reservations.Any())
                .OrderByDescending(c => c.Reservations.Max(r => r.Start))
                .Take(5)
                .ToList();

            var topMakes = vehicleDbContext.Reservations
                .Include(r => r.Car)
                .Where(r => r.Car != null)
                .GroupBy(r => r.Car.Make)
                .Select(g => new
                {
                    Make = g.Key,
                    Count = g.Count()
                })
                .OrderByDescending(g => g.Count)
                .Take(4)
                .ToList();

            // Send data to the view
            ViewBag.TotalVehicles = totalVehicles;
            ViewBag.RentedVehicles = rentedVehicles;
            ViewBag.AvailableVehicles = availableVehicles;
            ViewBag.MaintenanceVehicles = maintenanceVehicles;

            ViewBag.TotalCustomers = totalCustomers;
            ViewBag.NewCustomers = newCustomersThisMonth;

            ViewBag.UpcomingReservations = upcomingReservations;
            ViewBag.ReservationDiffText = diffText;
            ViewBag.RecurringCustomers = recentCustomers;
            ViewBag.TopRentedMakes = topMakes;
            return View();
        }
        [HttpGet]
        [Route("reports")]
        public async Task<IActionResult> Reports()
        {
            if (!AuthCheck())
                return RedirectToAction("Login", "Account");

            var reservations = await vehicleDbContext.Reservations
                .Include(r => r.Car)
                .Include(r => r.Renter)
                .ToListAsync();

            var totalReservations = reservations.Count;

            // Most Rented Model
            var modelStats = reservations
                .Where(r => r.Car != null)
                .GroupBy(r => r.Car.Model)
                .OrderByDescending(g => g.Count())
                .Select(g => new { Model = g.Key, Count = g.Count() })
                .FirstOrDefault();

            string mostRentedModel = modelStats?.Model ?? "N/A";
            int mostRentedModelPct = totalReservations > 0 ? (int)((double)(modelStats?.Count ?? 0) / totalReservations * 100) : 0;

            // Average Rental Duration
            double avgRentalDays = reservations.Any()
                ? reservations.Average(r => (r.End - r.Start).TotalDays)
                : 0;

            // Peak Month
            var peakMonthGroup = reservations
                .GroupBy(r => r.Start.Month)
                .OrderByDescending(g => g.Count())
                .FirstOrDefault();

            int peakMonthPct = totalReservations > 0 ? (int)((double)(peakMonthGroup?.Count() ?? 0) / totalReservations * 100) : 0;
            string peakMonth = peakMonthGroup != null ? new DateTime(2025, peakMonthGroup.Key, 1).ToString("MMMM") : "N/A";

            // Late Return Rate
            int lateReturns = reservations.Count(r => r.End < DateTime.Today && r.Status != "Completed");
            int lateReturnRate = totalReservations > 0 ? (int)((double)lateReturns / totalReservations * 100) : 0;

            // Payment Preferences
            var paymentGroup = vehicleDbContext.Customers
                .GroupBy(c => c.PaymentType)
                .OrderByDescending(g => g.Count())
                .Select(g => new { Type = g.Key, Count = g.Count() })
                .ToList();

            var topPayment = paymentGroup.FirstOrDefault();
            string topPaymentType = topPayment?.Type ?? "N/A";
            int topPaymentPercentage = paymentGroup.Sum(g => g.Count) > 0
                ? (int)((double)(topPayment?.Count ?? 0) / paymentGroup.Sum(g => g.Count) * 100)
                : 0;

            // New vs Returning
            var customers = await vehicleDbContext.Customers
                .Include(c => c.Reservations)
                .ToListAsync();

            int newCustomers = customers.Count(c => c.Reservations.Count == 1);
            int returningCustomers = customers.Count(c => c.Reservations.Count > 1);
            int totalCustomers = newCustomers + returningCustomers;

            int newPct = totalCustomers > 0 ? (int)((double)newCustomers / totalCustomers * 100) : 0;
            int returningPct = totalCustomers > 0 ? (int)((double)returningCustomers / totalCustomers * 100) : 0;

            var vm = new ReportsVM
            {
                MostRentedModel = mostRentedModel,
                MostRentedModelPercentage = mostRentedModelPct,
                AverageRentalDays = Math.Round(avgRentalDays, 1),
                PeakRentalMonth = peakMonth,
                PeakRentalMonthPercentage = peakMonthPct,
                LateReturnRate = lateReturnRate,
                TopPaymentType = topPaymentType,
                TopPaymentPercentage = topPaymentPercentage,
                NewPercentage = newPct,
                ReturningPercentage = returningPct
            };

            return View(vm);
        }

    }
}
