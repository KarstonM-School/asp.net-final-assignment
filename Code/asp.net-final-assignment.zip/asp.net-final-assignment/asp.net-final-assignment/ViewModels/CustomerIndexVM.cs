﻿using asp.net_final_assignment.Models;

namespace asp.net_final_assignment.ViewModels
{
    public class CustomerIndexVM
    {
        public List<Customer> Customers { get; set; }
    }
}
