﻿namespace asp.net_final_assignment.ViewModels
{
    public class ReportsVM
    {
        public string MostRentedModel { get; set; }
        public double MostRentedModelPercentage { get; set; }

        public double AverageRentalDays { get; set; }

        public string PeakRentalMonth { get; set; }
        public double PeakRentalMonthPercentage { get; set; }

        public double LateReturnRate { get; set; }

        public string TopPaymentType { get; set; }
        public double TopPaymentPercentage { get; set; }

        public double NewPercentage { get; set; }
        public double ReturningPercentage { get; set; }
    }
}
